package com.example.dolgozatglobalisvaltozo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.dolgozatglobalisvaltozo.R;

public class MainActivity extends AppCompatActivity {

    private Button buttonKuldes;
    private EditText editTextBemenet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        buttonKuldes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Globális változó
                //file létrehozás
                SharedPreferences sharedPreferences = getSharedPreferences("Adatok", Context.MODE_PRIVATE);
                //megnyitás és beleírás
                SharedPreferences.Editor editor = sharedPreferences.edit();
                //Adatok.xml ==> String nev = editTextBemenet
                editor.putString("nev", editTextBemenet.getText().toString());
                //Végrehajtás művelet
                editor.apply();

                Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void init()
    {
        buttonKuldes = findViewById(R.id.buttonKovetkezo);
        editTextBemenet = findViewById(R.id.editTextBemenet);
    }
}
