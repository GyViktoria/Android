package com.example.dolgozatglobalisvaltozo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private TextView textViewKimenet;
    private Button buttonKovetkezo, buttonValtoztatas, buttonInformacio, buttonKilepes;
    private android.app.AlertDialog alertDialog;
    private AlertDialog.Builder alertKilepesBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        init();

        SharedPreferences sharedPreferences = getSharedPreferences("Adatok", Context.MODE_PRIVATE);
        String seged = "";
        //Adat leszedés
        seged = sharedPreferences.getString("nev","Nincs elmentve a neved!");

        textViewKimenet.setText(seged);
        buttonKovetkezo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SecondActivity.this,ThirdActivity.class);
                startActivity(intent);
                finish();

            }
        });

        buttonValtoztatas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondActivity.this,FourthActivity.class);
                startActivity(intent);
                finish();
            }
        });

        buttonKilepes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertKilepesBox.create().show();
            }
        });

    }

    public void init()
    {
        textViewKimenet = findViewById(R.id.textViewKimenet);
        buttonKovetkezo = findViewById(R.id.buttonKovetkezoActivitire);
        buttonValtoztatas = findViewById(R.id.buttonNevvaltoztatas);
        buttonInformacio = findViewById(R.id.buttonInformacio);
        buttonKilepes = findViewById(R.id.buttonKilepes);

        alertKilepesBox  = new AlertDialog.Builder(SecondActivity.this);
        alertKilepesBox.setMessage("Biztosan ki akarsz lépni a programból?");
        alertKilepesBox.setTitle("Biztos kilépsz");
        alertKilepesBox.setPositiveButton("Nem", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                startActivity(getIntent());
            }
        });
        alertKilepesBox.setNegativeButton("Igen", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
    }
}
