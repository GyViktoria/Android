package com.example.dolgozatglobalisvaltozo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FourthActivity extends AppCompatActivity {

    private EditText valtoztathato;
    private Button kuldes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth);
        init();
        SharedPreferences sharedPreferences = getSharedPreferences("Adatok", Context.MODE_PRIVATE);
        String seged = "";
        //Adat leszedés
        seged = sharedPreferences.getString("nev","Nincs elmentve a neved!");
        valtoztathato.setText(seged);

        kuldes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("Adatok", Context.MODE_PRIVATE);
                //megnyitás és beleírás
                SharedPreferences.Editor editor = sharedPreferences.edit();
                //Adatok.xml ==> String nev = editTextBemenet
                editor.putString("nev", valtoztathato.getText().toString());
                //Végrehajtás művelet
                editor.apply();

                Intent intent = new Intent(FourthActivity.this,SecondActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void init(){
        valtoztathato = findViewById(R.id.editTextValtoztathato);
        kuldes = findViewById(R.id.buttonValtoztatas);
    }
}
