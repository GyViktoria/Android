package com.example.kockadobasjatek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private ImageView kepGep, kepEmber;
    private  int gepDobasa, emberDobasa;
    private Button dobasButton;
    private Random r = new Random();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        dobasButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gepDobasa = r.nextInt(6) + 1;
                emberDobasa = r.nextInt(6) + 1;
                switch (gepDobasa){
                    case 1: kepGep.setImageResource(R.drawable.kep1);
                        break;
                    case 2: kepGep.setImageResource(R.drawable.kep2);
                        break;
                    case 3: kepGep.setImageResource(R.drawable.kep3);
                        break;
                    case 4: kepGep.setImageResource(R.drawable.kep4);
                        break;
                    case 5: kepGep.setImageResource(R.drawable.kep5);
                        break;
                    case 6: kepGep.setImageResource(R.drawable.kep6);
                        break;
                }
                switch (emberDobasa) {
                    case 1:
                        kepEmber.setImageResource(R.drawable.kep1);
                        break;
                    case 2:
                        kepEmber.setImageResource(R.drawable.kep2);
                        break;
                    case 3:
                        kepEmber.setImageResource(R.drawable.kep3);
                        break;
                    case 4:
                        kepEmber.setImageResource(R.drawable.kep4);
                        break;
                    case 5:
                        kepEmber.setImageResource(R.drawable.kep5);
                        break;
                    case 6:
                        kepEmber.setImageResource(R.drawable.kep6);
                        break;
                }
                if (gepDobasa > emberDobasa){
                    Toast.makeText(MainActivity.this, "Vesztettél!", Toast.LENGTH_SHORT).show();
                }
                else if (emberDobasa > gepDobasa){
                    Toast.makeText(MainActivity.this, "Nyertél!", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Döntetlen!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void init(){
        kepEmber = findViewById(R.id.kepEmber);
        kepGep = findViewById(R.id.kepGep);
        dobasButton = findViewById(R.id.buttonDobas);
        gepDobasa = 0;
        emberDobasa = 0;
    }
}
