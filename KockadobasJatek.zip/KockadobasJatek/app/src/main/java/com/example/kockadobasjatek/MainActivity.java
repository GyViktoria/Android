package com.example.kockadobasjatek;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private ImageView kepGep, kepEmber, hearts;
    private  int gepDobasa, emberDobasa, emberElet, lehetosegek;
    private Button dobasButton;
    private Random r = new Random();
    private android.app.AlertDialog alertDialog;
    private AlertDialog.Builder alertWin, alertLose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        dobasButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gepDobasa = r.nextInt(6) + 1;
                emberDobasa = r.nextInt(6) + 1;
                switch (gepDobasa){
                    case 1: kepGep.setImageResource(R.drawable.kep1);
                        break;
                    case 2: kepGep.setImageResource(R.drawable.kep2);
                        break;
                    case 3: kepGep.setImageResource(R.drawable.kep3);
                        break;
                    case 4: kepGep.setImageResource(R.drawable.kep4);
                        break;
                    case 5: kepGep.setImageResource(R.drawable.kep5);
                        break;
                    case 6: kepGep.setImageResource(R.drawable.kep6);
                        break;
                }
                switch (emberDobasa) {
                    case 1:
                        kepEmber.setImageResource(R.drawable.kep1);
                        break;
                    case 2:
                        kepEmber.setImageResource(R.drawable.kep2);
                        break;
                    case 3:
                        kepEmber.setImageResource(R.drawable.kep3);
                        break;
                    case 4:
                        kepEmber.setImageResource(R.drawable.kep4);
                        break;
                    case 5:
                        kepEmber.setImageResource(R.drawable.kep5);
                        break;
                    case 6:
                        kepEmber.setImageResource(R.drawable.kep6);
                        break;
                }
                if (gepDobasa > emberDobasa){
                    emberElet--;
                    lehetosegek--;
                    Toast.makeText(MainActivity.this, "Elvesztetted a kört!! " + lehetosegek + " lehetőséged maradt", Toast.LENGTH_SHORT).show();

                }
                else if (emberDobasa > gepDobasa){
                    lehetosegek--;
                    Toast.makeText(MainActivity.this, "Megnyerted a kört! " + lehetosegek + " lehetőséged maradt", Toast.LENGTH_SHORT).show();

                }
                else{
                    lehetosegek--;
                    Toast.makeText(MainActivity.this, "A kör döntetlen! " + lehetosegek + " lehetőséged maradt", Toast.LENGTH_SHORT).show();

                }
                switch (emberElet){
                    case 3:
                        hearts.setImageResource(R.drawable.heartsthree);
                        break;
                    case 2:
                        hearts.setImageResource(R.drawable.heartstwo);
                        break;
                    case 1:
                        hearts.setImageResource(R.drawable.heartsone);
                        break;
                    case 0:
                        hearts.setImageResource(R.drawable.heartsempty);
                        break;
                }
                if (lehetosegek == 0 || emberElet == 0){
                    if (emberElet != 0){
                        alertWin.create().show();
                    }else {
                        alertLose.create().show();
                    }

                }
            }
        });
    }

    public void init(){
        kepEmber = findViewById(R.id.kepEmber);
        kepGep = findViewById(R.id.kepGep);
        hearts = findViewById(R.id.hearts);
        dobasButton = findViewById(R.id.buttonDobas);
        gepDobasa = 0;
        emberDobasa = 0;
        emberElet = 3;
        lehetosegek = 5;

        alertWin  = new AlertDialog.Builder(MainActivity.this);
            alertWin.setMessage("Szeretnél játszani még egyet?");
            alertWin.setTitle("Nyertél!");
            alertWin.setPositiveButton("Igen", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                    startActivity(getIntent());
                }
            });
            alertWin.setNegativeButton("Nem", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });


        alertLose  = new AlertDialog.Builder(MainActivity.this);
        alertLose.setMessage("Szeretnél játszani még egyet?");
        alertLose.setTitle("Vesztettél!");
        alertLose.setPositiveButton("Igen", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                startActivity(getIntent());
            }
        });
        alertLose.setNegativeButton("Nem", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
    }
}

